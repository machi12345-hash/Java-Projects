const https = require('https');

// Load package.json of the Project
let projectPackageJson;
try {
  projectPackageJson = require(process.env.INIT_CWD + '/package.json');
} catch (error) {
  console.error(
    'FEDEV Analytics Tracking: Error retrieving package.json of the project'
  );
  console.error('FEDEV Analytics Tracking: Exiting process');
  process.exit();
}

// Collect dependencies and other project information
const { name, version, dependencies, devDependencies } = projectPackageJson;
const packageName = '@bmw-fedev/boilerplate';

const data = {
  projectName: name,
  projectVersion: version,
  angularVersion: dependencies['@angular/core'] || '',
  dependencies: dependencies,
  devDependencies: devDependencies,
  usesTemplate: true,
  packageName: packageName,
  packageVersion: '',
};

const jsonData = JSON.stringify(data);

// Define the request options
const options = {
  host: 'analytics-api-fedevanalytics-prod-2y2i.scp.eu-central-1.aws.cloud.bmw',
  path: '/api/v1/projects',
  method: 'POST',
  rejectUnauthorized: false,
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(jsonData),
  },
};

// Send the request
const req = https.request(options, (res) => {
  res.on('data', (d) => process.stdout.write(d));
});

// Set a timeout for the request
const requestTimeout = 8000;
setTimeout(() => req.abort(), requestTimeout);

// Handle errors and response from the request
const trackingDocumentationURL =
  'https://atc.bmwgroup.net/confluence/display/COPUX/Analytics';

req.on('error', (error) => {
  let errorString =
    typeof error === 'object' ? JSON.stringify(error) : String(error);
  const sanitizedError = errorString.replace(/[^\w\s.]/gi, '');
  console.warn(
    `FEDEV Analytics - tracking error. See more about the FEDEV Analytics tracking on ${trackingDocumentationURL}`
  );
  console.warn(sanitizedError);
});

req.on('response', (res) => {
  if (res.statusCode === 201) {
    console.info(
      'Successfully submitted application install to the FEDEV Analytics tracking'
    );
  } else {
    console.warn(
      `FEDEV Analytics - tracking error. See more about the FEDEV Analytics tracking on ${trackingDocumentationURL}`
    );
  }
});

// Write data and end the request
req.write(jsonData);
req.end();
