const fs = require('fs');
const path = require('path');
const data = require('../../../coverage/coverage-summary.json');
const jestConfigs = require('../../../jest.config');

const pctToColor = (pct, metric) => (pct > metric ? 'success' : 'critical');

const run = () => {
  const keys = Object.keys(data);
  const valuesForKeys = keys.reduce(
    (acc, key) => [
      ...acc,
      `| ${key.split('/').pop()} | ${data[key].lines.pct}% | ${
        data[key].functions.pct
      }% | ${data[key].statements.pct}% | ${data[key].branches.pct}% |`,
    ],
    []
  );

  let mdResult = `# Coverage Overview

  <img src="https://img.shields.io/badge/Line%20Coverage-${
    data.total.lines.pct
  }%25-${pctToColor(
    data.total.lines.pct,
    jestConfigs.coverageThreshold.global.lines
  )}?style=flat" alt="Code Coverage" style="max-width: 100%;">
  <img src="https://img.shields.io/badge/Function%20Coverage-${
    data.total.functions.pct
  }%25-${pctToColor(
    data.total.functions.pct,
    jestConfigs.coverageThreshold.global.functions
  )}?style=flat" alt="Code Coverage" style="max-width: 100%;">
  <img src="https://img.shields.io/badge/Statement%20Coverage-${
    data.total.statements.pct
  }%25-${pctToColor(
    data.total.statements.pct,
    jestConfigs.coverageThreshold.global.statements
  )}?style=flat" alt="Code Coverage" style="max-width: 100%;">
  <img src="https://img.shields.io/badge/Branch%20Coverage-${
    data.total.branches.pct
  }%25-${pctToColor(
    data.total.branches.pct,
    jestConfigs.coverageThreshold.global.branches
  )}?style=flat" alt="Code Coverage" style="max-width: 100%;">

  | module | lines           | functions    | statements           | branches    |
  | ---- | ------------- | --------------- | -------- | -------- |
  `;

  mdResult = mdResult.concat(valuesForKeys.join('\n'));

  fs.writeFileSync(path.join('./coverage/coverage-summary.md'), mdResult);
};

run();
