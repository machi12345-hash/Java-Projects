import { axe } from 'jest-axe';
import { AppComponent } from './app.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';

describe('AppComponent accessibility', () => {
  let fixture: ComponentFixture<AppComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AppComponent],
    });

    fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
  });

  it('should have no accessibility issues', async () => {
    // Check our documentation for more information on the available options.
    const results = await axe(fixture.nativeElement);
    expect(results).toHaveNoViolations();
  });
});

describe('AppComponent', () => {
  let component: AppComponent;

  beforeEach(() => {
    component = new AppComponent();
  });

  it('should instantiate the component', () => {
    expect(component).toBeTruthy();
  });

  it(`should have as title 'bmw-angular-boilerplate'`, () => {
    expect(component.title).toBe('bmw-angular-boilerplate');
  });
});
